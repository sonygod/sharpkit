Ext.data.JsonP.Ext_layout_Layout({
  "mixedInto": [

  ],
  "superclasses": [

  ],
  "inheritable": false,
  "subclasses": [
    "Ext.layout.container.AbstractContainer"
  ],
  "deprecated": null,
  "allMixins": [

  ],
  "href": "Layout.html#Ext-layout-Layout",
  "members": {
    "cfg": [

    ],
    "method": [

    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ],
    "property": [

    ]
  },
  "singleton": false,
  "protected": false,
  "tagname": "class",
  "mixins": [

  ],
  "alias": null,
  "author": null,
  "filename": "/mnt/ebs/nightly/git/SDK/platform/src/layout/Layout.js",
  "private": false,
  "alternateClassNames": [

  ],
  "static": false,
  "name": "Ext.layout.Layout",
  "doc": "<p>Base Layout class - extended by ComponentLayout and ContainerLayout</p>\n",
  "docauthor": null,
  "component": false,
  "linenr": 1,
  "xtypes": [

  ],
  "html_filename": "Layout.html",
  "statics": {
    "cfg": [

    ],
    "method": [

    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ],
    "property": [

    ]
  },
  "extends": "Object"
});